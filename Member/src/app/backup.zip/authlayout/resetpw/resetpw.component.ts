import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resetpw',
  templateUrl: './resetpw.component.html',
  styleUrls: ['./resetpw.component.scss']
})
export class ResetpwComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
