import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staticfooter',
  templateUrl: './staticfooter.component.html',
  styleUrls: ['./staticfooter.component.scss']
})
export class StaticfooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
