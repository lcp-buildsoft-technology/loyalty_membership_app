import { Component, OnInit, Renderer2 } from '@angular/core';

import SwiperCore, {
  Navigation,
  Pagination,
  Scrollbar,
  A11y,
} from 'swiper/core';
SwiperCore.use([Navigation, Pagination, Scrollbar, A11y]);

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})

export class HomeComponent implements OnInit {
  isChecked: boolean = false;

  constructor(private renderer: Renderer2) { }

  ngOnInit(): void {
    const ulElement: any = document.getElementsByClassName('date-list')[0];
    const liwidth:any = document.querySelectorAll('ul.date-list li')[0].clientWidth;
    const datelist = (document.querySelectorAll('ul.date-list li').length)*liwidth;
    this.renderer.setAttribute(ulElement, 'style', "width:"+datelist+"px;");      

  }
  doCheck() {
    let html = document.getElementsByTagName('html')[0];
    this.isChecked = !this.isChecked;
    if (this.isChecked == true) {
      html.classList.add('dark-mode');
    } else {
      html.classList.remove('dark-mode');
    }
  }

}
