import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-referralrewardshome',
  templateUrl: './referralrewardshome.component.html',
  styleUrls: ['./referralrewardshome.component.scss']
})
export class ReferralrewardshomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
