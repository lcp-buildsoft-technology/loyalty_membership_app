import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voucherdetails',
  templateUrl: './voucherdetails.component.html',
  styleUrls: ['./voucherdetails.component.scss']
})
export class VoucherdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
