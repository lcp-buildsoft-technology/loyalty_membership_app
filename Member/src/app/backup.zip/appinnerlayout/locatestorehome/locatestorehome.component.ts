import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-locatestorehome',
  templateUrl: './locatestorehome.component.html',
  styleUrls: ['./locatestorehome.component.scss']
})
export class LocatestorehomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
