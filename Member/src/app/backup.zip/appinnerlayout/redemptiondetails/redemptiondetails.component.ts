import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-redemptiondetails',
  templateUrl: './redemptiondetails.component.html',
  styleUrls: ['./redemptiondetails.component.scss']
})
export class RedemptiondetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
