import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingeventstatusComponent } from './bookingeventstatus.component';

describe('BookingeventstatusComponent', () => {
  let component: BookingeventstatusComponent;
  let fixture: ComponentFixture<BookingeventstatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookingeventstatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingeventstatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
