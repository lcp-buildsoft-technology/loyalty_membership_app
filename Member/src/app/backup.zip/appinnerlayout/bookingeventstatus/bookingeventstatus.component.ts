import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingeventstatus',
  templateUrl: './bookingeventstatus.component.html',
  styleUrls: ['./bookingeventstatus.component.scss']
})
export class BookingeventstatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
