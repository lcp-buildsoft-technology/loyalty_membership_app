import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-birthdayreminder',
  templateUrl: './birthdayreminder.component.html',
  styleUrls: ['./birthdayreminder.component.scss']
})
export class BirthdayreminderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
