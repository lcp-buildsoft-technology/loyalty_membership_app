import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BirthdayreminderComponent } from './birthdayreminder.component';

describe('BirthdayreminderComponent', () => {
  let component: BirthdayreminderComponent;
  let fixture: ComponentFixture<BirthdayreminderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BirthdayreminderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BirthdayreminderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
