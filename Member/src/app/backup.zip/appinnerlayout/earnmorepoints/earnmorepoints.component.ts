import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-earnmorepoints',
  templateUrl: './earnmorepoints.component.html',
  styleUrls: ['./earnmorepoints.component.scss']
})
export class EarnmorepointsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
