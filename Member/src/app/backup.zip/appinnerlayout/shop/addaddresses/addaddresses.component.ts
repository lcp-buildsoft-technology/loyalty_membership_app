import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addaddresses',
  templateUrl: './addaddresses.component.html',
  styleUrls: ['./addaddresses.component.scss']
})
export class AddaddressesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
