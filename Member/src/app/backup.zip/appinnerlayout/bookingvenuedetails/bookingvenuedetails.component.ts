import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingvenuedetails',
  templateUrl: './bookingvenuedetails.component.html',
  styleUrls: ['./bookingvenuedetails.component.scss']
})
export class BookingvenuedetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
