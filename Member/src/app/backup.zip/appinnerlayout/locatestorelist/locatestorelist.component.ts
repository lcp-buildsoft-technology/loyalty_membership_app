import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-locatestorelist',
  templateUrl: './locatestorelist.component.html',
  styleUrls: ['./locatestorelist.component.scss']
})
export class LocatestorelistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
