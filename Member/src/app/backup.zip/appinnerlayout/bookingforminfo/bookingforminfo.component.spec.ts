import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingforminfoComponent } from './bookingforminfo.component';

describe('BookingforminfoComponent', () => {
  let component: BookingforminfoComponent;
  let fixture: ComponentFixture<BookingforminfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookingforminfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingforminfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
