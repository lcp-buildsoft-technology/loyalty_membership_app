import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingforminfo',
  templateUrl: './bookingforminfo.component.html',
  styleUrls: ['./bookingforminfo.component.scss']
})
export class BookingforminfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
