import { Component, OnInit } from '@angular/core';
import SwiperCore, {
  Navigation,
  Pagination,
  Scrollbar,
  A11y,
} from 'swiper/core';
SwiperCore.use([Navigation, Pagination, Scrollbar, A11y]);

@Component({
  selector: 'app-locatestoredetails',
  templateUrl: './locatestoredetails.component.html',
  styleUrls: ['./locatestoredetails.component.scss']
})
export class LocatestoredetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    var html5Slider = document.getElementById('rangeslider');
  }
  

}
