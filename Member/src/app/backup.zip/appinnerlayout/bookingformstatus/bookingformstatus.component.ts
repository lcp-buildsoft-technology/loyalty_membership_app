import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingformstatus',
  templateUrl: './bookingformstatus.component.html',
  styleUrls: ['./bookingformstatus.component.scss']
})
export class BookingformstatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
