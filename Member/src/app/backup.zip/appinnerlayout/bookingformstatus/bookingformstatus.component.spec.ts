import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingformstatusComponent } from './bookingformstatus.component';

describe('BookingformstatusComponent', () => {
  let component: BookingformstatusComponent;
  let fixture: ComponentFixture<BookingformstatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookingformstatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingformstatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
