import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingeventpayment2',
  templateUrl: './bookingeventpayment2.component.html',
  styleUrls: ['./bookingeventpayment2.component.scss']
})
export class Bookingeventpayment2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
