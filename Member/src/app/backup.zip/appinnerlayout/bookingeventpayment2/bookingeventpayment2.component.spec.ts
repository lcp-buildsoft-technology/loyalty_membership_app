import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Bookingeventpayment2Component } from './bookingeventpayment2.component';

describe('Bookingeventpayment2Component', () => {
  let component: Bookingeventpayment2Component;
  let fixture: ComponentFixture<Bookingeventpayment2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Bookingeventpayment2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Bookingeventpayment2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
