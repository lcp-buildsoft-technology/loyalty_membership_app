import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-redemptiontransaction',
  templateUrl: './redemptiontransaction.component.html',
  styleUrls: ['./redemptiontransaction.component.scss']
})
export class RedemptiontransactionComponent implements OnInit {
  showDiv = {
    All: false,
    Today: false,
    Yesterday: false,
  }

  constructor() { }

  ngOnInit(): void {
  }

}
