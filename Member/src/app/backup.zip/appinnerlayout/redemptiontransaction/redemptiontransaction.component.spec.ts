import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RedemptiontransactionComponent } from './redemptiontransaction.component';

describe('RedemptiontransactionComponent', () => {
  let component: RedemptiontransactionComponent;
  let fixture: ComponentFixture<RedemptiontransactionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RedemptiontransactionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RedemptiontransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
