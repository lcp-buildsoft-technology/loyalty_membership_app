import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingvenuelist',
  templateUrl: './bookingvenuelist.component.html',
  styleUrls: ['./bookingvenuelist.component.scss']
})
export class BookingvenuelistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
