import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-birthdayrewardshome',
  templateUrl: './birthdayrewardshome.component.html',
  styleUrls: ['./birthdayrewardshome.component.scss']
})
export class BirthdayrewardshomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
