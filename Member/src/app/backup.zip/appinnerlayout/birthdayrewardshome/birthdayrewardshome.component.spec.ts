import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BirthdayrewardshomeComponent } from './birthdayrewardshome.component';

describe('BirthdayrewardshomeComponent', () => {
  let component: BirthdayrewardshomeComponent;
  let fixture: ComponentFixture<BirthdayrewardshomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BirthdayrewardshomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BirthdayrewardshomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
