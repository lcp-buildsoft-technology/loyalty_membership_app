import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gamificationprizehistory',
  templateUrl: './gamificationprizehistory.component.html',
  styleUrls: ['./gamificationprizehistory.component.scss']
})
export class GamificationprizehistoryComponent implements OnInit {
  showDiv = {
    All: false,
    Today: false,
    Yesterday: false,
  }

  constructor() { }

  ngOnInit(): void {
  }

}
