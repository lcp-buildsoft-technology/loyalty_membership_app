import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingeventhome',
  templateUrl: './bookingeventhome.component.html',
  styleUrls: ['./bookingeventhome.component.scss']
})
export class BookingeventhomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
