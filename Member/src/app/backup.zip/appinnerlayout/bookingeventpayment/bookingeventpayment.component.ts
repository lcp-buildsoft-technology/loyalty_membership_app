import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingeventpayment',
  templateUrl: './bookingeventpayment.component.html',
  styleUrls: ['./bookingeventpayment.component.scss']
})
export class BookingeventpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
