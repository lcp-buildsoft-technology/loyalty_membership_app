import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingeventdetails',
  templateUrl: './bookingeventdetails.component.html',
  styleUrls: ['./bookingeventdetails.component.scss']
})
export class BookingeventdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
