import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingvenuehome',
  templateUrl: './bookingvenuehome.component.html',
  styleUrls: ['./bookingvenuehome.component.scss']
})
export class BookingvenuehomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
