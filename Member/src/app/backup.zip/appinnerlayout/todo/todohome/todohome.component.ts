import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todohome',
  templateUrl: './todohome.component.html',
  styleUrls: ['./todohome.component.scss']
})
export class TodohomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
