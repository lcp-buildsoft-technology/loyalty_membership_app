import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onlinestorehome',
  templateUrl: './onlinestorehome.component.html',
  styleUrls: ['./onlinestorehome.component.scss']
})
export class OnlinestorehomeComponent implements OnInit {
  showDiv = {
    Western:false,
    Spicy: false,
    Vegetarian: false,
    NonVegetarian: false
  }

  constructor() { }

  ngOnInit(): void {
  }

}
