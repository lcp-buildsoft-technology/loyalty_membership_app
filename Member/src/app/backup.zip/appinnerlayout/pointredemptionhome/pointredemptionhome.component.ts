import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pointredemptionhome',
  templateUrl: './pointredemptionhome.component.html',
  styleUrls: ['./pointredemptionhome.component.scss']
})
export class PointredemptionhomeComponent implements OnInit {
  showDiv = {
    History: false,
    New: false
  }

  constructor() { }

  ngOnInit(): void {
  }

}
