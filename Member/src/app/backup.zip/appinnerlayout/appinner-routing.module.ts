import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppinnerlayoutComponent } from './appinnerlayout.component';
import { ShophomeComponent } from './shop/shophome/shophome.component';
import { ProductComponent } from './shop/product/product.component';
import { CartComponent } from './shop/cart/cart.component';
import { PaymentComponent } from './shop/payment/payment.component';
import { MyordersComponent } from './shop/myorders/myorders.component';
import { OrderdetailComponent } from './shop/orderdetail/orderdetail.component';
import { ShopThankyouComponent } from './shop/thankyou/thankyou.component';
import { AddaddressesComponent } from './shop/addaddresses/addaddresses.component';
import { AddressesComponent } from './shop/addresses/addresses.component';
import { TodohomeComponent } from './todo/todohome/todohome.component';
import { TaskcalendarComponent } from './todo/taskcalendar/taskcalendar.component';
import { TodaystaskComponent } from './todo/todaystask/todaystask.component';
import { EventsComponent } from './todo/events/events.component';
import { EventdetailsComponent } from './todo/eventdetails/eventdetails.component';
import { PagesComponent } from './pages/pages.component';
import { SettingsComponent } from './settings/settings.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { MessagesComponent } from './messages/messages.component';
import { ChatlistComponent } from './chatlist/chatlist.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { FaqsComponent } from './faqs/faqs.component';
import { UserlistComponent } from './userlist/userlist.component';
import { TimelineComponent } from './timeline/timeline.component';
import { ContactusComponent } from './contactus/contactus.component';
import { PricingComponent } from './pricing/pricing.component';
import { TermsandcoditionComponent } from './termsandcodition/termsandcodition.component';
import { InvoiceComponent } from './shop/invoice/invoice.component';
import { AdvertisementComponent } from './shop/advertisement/advertisement.component';
import { LocatestorehomeComponent } from './locatestorehome/locatestorehome.component';
import { LocatestorelistComponent } from './locatestorelist/locatestorelist.component';
import { LocatestoredetailsComponent } from './locatestoredetails/locatestoredetails.component';
import { OnlinestorehomeComponent } from './onlinestorehome/onlinestorehome.component';
import { OnlinestoredetailsComponent } from './onlinestoredetails/onlinestoredetails.component';
import { BookingvenuehomeComponent } from './bookingvenuehome/bookingvenuehome.component';
import { BookingvenuelistComponent } from './bookingvenuelist/bookingvenuelist.component';
import { BookingvenuedetailsComponent } from './bookingvenuedetails/bookingvenuedetails.component';
import { BookingformdateComponent } from './bookingformdate/bookingformdate.component';
import { BookingforminfoComponent } from './bookingforminfo/bookingforminfo.component';
import { BookingformstatusComponent } from './bookingformstatus/bookingformstatus.component';
import { BookingeventhomeComponent } from './bookingeventhome/bookingeventhome.component';
import { BookingeventdetailsComponent } from './bookingeventdetails/bookingeventdetails.component';
import { BookingeventpaymentComponent } from './bookingeventpayment/bookingeventpayment.component';
import { Bookingeventpayment2Component } from './bookingeventpayment2/bookingeventpayment2.component';
import { Bookingeventpayment3Component } from './bookingeventpayment3/bookingeventpayment3.component';
import { BookingeventstatusComponent } from './bookingeventstatus/bookingeventstatus.component';
import { BookingtransactionComponent } from './bookingtransaction/bookingtransaction.component';
import { VoucherhomeComponent } from './voucherhome/voucherhome.component';
import { VoucherdetailsComponent } from './voucherdetails/voucherdetails.component';
import { TieredloyaltyprogramComponent } from './tieredloyaltyprogram/tieredloyaltyprogram.component';
import { EarnmorepointsComponent } from './earnmorepoints/earnmorepoints.component';
import { BookingeventformComponent } from './bookingeventform/bookingeventform.component';
import { BirthdayrewardshomeComponent } from './birthdayrewardshome/birthdayrewardshome.component';
import { BirthdayreminderComponent } from './birthdayreminder/birthdayreminder.component';
import { ReferralrewardshomeComponent } from './referralrewardshome/referralrewardshome.component';
import { ReferralrewardstatusComponent } from './referralrewardstatus/referralrewardstatus.component';
import { RedemptiontransactionComponent } from './redemptiontransaction/redemptiontransaction.component';
import { CollectedtransactionComponent } from './collectedtransaction/collectedtransaction.component';
import { PointredemptionhomeComponent } from './pointredemptionhome/pointredemptionhome.component';
import { RedemptiondetailsComponent } from './redemptiondetails/redemptiondetails.component';
import { GamificationhomeComponent } from './gamificationhome/gamificationhome.component';
import { GamificationprizehistoryComponent } from './gamificationprizehistory/gamificationprizehistory.component';
import { MyaccountComponent } from './myaccount/myaccount.component';
import { BookinghistoryComponent } from './bookinghistory/bookinghistory.component';

const routes: Routes = [
  {
    path: '',
    component: AppinnerlayoutComponent,

    children: [

      //Store
      {
        path: 'locatestorehome',
        component: LocatestorehomeComponent,
      },
      {
        path: 'locatestorelist',
        component: LocatestorelistComponent,
      },
      {
        path: 'locatestoredetails',
        component: LocatestoredetailsComponent,
      },
      {
        path: 'onlinestorehome',
        component: OnlinestorehomeComponent,
      },
      {
        path: 'onlinestoredetails',
        component: OnlinestoredetailsComponent,
      },

      //Online Booking
      //Venue
      {
        path: 'bookingvenuehome',
        component: BookingvenuehomeComponent,
      },
      {
        path: 'bookingvenuelist',
        component: BookingvenuelistComponent,
      },
      {
        path: 'bookingvenuedetails',
        component: BookingvenuedetailsComponent,
      },
      {
        path: 'bookingformdate',
        component: BookingformdateComponent,
      },
      {
        path: 'bookingforminfo',
        component: BookingforminfoComponent,
      },
      {
        path: 'bookingformstatus',
        component: BookingformstatusComponent,
      },
      //Event
      {
        path: 'bookingeventhome',
        component: BookingeventhomeComponent,
      },
      {
        path: 'bookingeventdetails',
        component: BookingeventdetailsComponent,
      },
      {
        path: 'bookingeventform',
        component: BookingeventformComponent,
      },
      {
        path: 'bookingeventpayment',
        component: BookingeventpaymentComponent,
      },
      {
        path: 'bookingeventpayment2',
        component: Bookingeventpayment2Component,
      },
      {
        path: 'bookingeventpayment3',
        component: Bookingeventpayment3Component,
      },
      {
        path: 'bookingeventstatus',
        component: BookingeventstatusComponent,
      },
      //Transaction
      {
        path: 'bookingtransaction',
        component: BookingtransactionComponent,
      },
      {
        path: 'bookinghistory',
        component: BookinghistoryComponent,
      },

      //Rewards
      //Voucher
      {
        path: 'voucherhome',
        component: VoucherhomeComponent,
      },
      {
        path: 'voucherdetails',
        component: VoucherdetailsComponent,
      },
      //tlp
      {
        path: 'tieredloyaltyprogram',
        component: TieredloyaltyprogramComponent,
      },
      //earnpoints
      {
        path: 'earnmorepoints',
        component: EarnmorepointsComponent,
      },
      //birthday rewards
      {
        path: 'birthdayrewardshome',
        component: BirthdayrewardshomeComponent,
      },
      {
        path: 'birthdayreminder',
        component: BirthdayreminderComponent,
      },
      //referral rewards
      {
        path: 'referralrewardshome',
        component: ReferralrewardshomeComponent,
      },
      {
        path: 'referralrewardstatus',
        component: ReferralrewardstatusComponent,
      },

      //Points Transaction
      //Redemption
      {
        path: 'redemptiontransaction',
        component: RedemptiontransactionComponent,
      },
      {
        path: 'collectedtransaction',
        component: CollectedtransactionComponent,
      },
      
      //point redemption program
      {
        path: 'pointredemptionhome',
        component: PointredemptionhomeComponent,
      },
      {
        path: 'redemptiondetails',
        component: RedemptiondetailsComponent,
      },
      
      //Gamification Progrma
      {
        path: 'gamificationhome',
        component: GamificationhomeComponent,
      },
      {
        path: 'gamificationprizehistory',
        component: GamificationprizehistoryComponent,
      },
      
      //My Account
      {
        path: 'myaccount',
        component: MyaccountComponent,
      },

      // Shopping pages 
      // {
      //   path: 'shophome',
      //   component: ShophomeComponent,
      // },
      // {
      //   path: 'shophome',
      //   component: EarnpointsComponent,
      // },
      // {
      //   path: 'shophome',
      //   component: PointredemptionprogramComponent,
      // },
      // {
      //   path: 'shophome',
      //   component: VoucherlistComponent,
      // },
      // {
      //   path: 'shophome',
      //   component: BirthdayrewardsComponent,
      // },
      // {
      //   path: 'shophome',
      //   component: BirthdaypopupComponent,
      // },
      // {
      //   path: 'shophome',
      //   component: ReferralrewardComponent,
      // },
      // {
      //   path: 'shophome',
      //   component: TlpComponent,
      // },
      // {
      //   path: 'shophome',
      //   component: FormbookeventComponent,
      // },
      // {
      //   path: 'shophome',
      //   component: Bookingvenueform1Component,
      // },
      // {
      //   path: 'shophome',
      //   component: Bookingvenueform2Component,
      // },
      // {
      //   path: 'shophome',
      //   component: SearchvenueComponent,
      // },
      // {
      //   path: 'shophome',
      //   component: ListvenueComponent,
      // },
      // {
      //   path: 'product',
      //   component: ProductComponent,
      // },
      // {
      //   path: 'product',
      //   component: VoucherdetailsComponent,
      // },
      // {
      //   path: 'product',
      //   component: BookingeventlistComponent,
      // },
      // {
      //   path: 'product',
      //   component: BookvenuedetailsComponent,
      // },
      // {
      //   path: 'product',
      //   component: OnlinestoredetailsComponent,
      // },
      // {
      //   path: 'product',
      //   component: OnlinestorelistmenuComponent,
      // },
      // {
      //   path: 'cart',
      //   component: CartComponent,
      // },
      // {
      //   path: 'cart',
      //   component: BookingvenuestatusComponent,
      // },
      // {
      //   path: 'cart',
      //   component: BookingeventstatusComponent,
      // },
      // {
      //   path: 'payment',
      //   component: PaymentComponent,
      // },
      // {
      //   path: 'payment',
      //   component: AdvertisementComponent,
      // },
      // {
      //   path: 'payment',
      //   component: PointredemptiondetailsComponent,
      // },
      // {
      //   path: 'payment',
      //   component: PointredemptiontransactionComponent,
      // },
      // {
      //   path: 'payment',
      //   component: PointcollectedtransactionComponent,
      // },
      // {
      //   path: 'payment',
      //   component: SpinprizehistoryComponent,
      // },
      // {
      //   path: 'payment',
      //   component: BookinglisttransactionComponent,
      // },
      // {
      //   path: 'payment',
      //   component: SuccessfulreferralsentComponent,
      // },
      // {
      //   path: 'myorders',
      //   component: MyordersComponent,
      // },
      // {
      //   path: 'myorders',
      //   component: GamificationprogramComponent,
      // },
      // {
      //   path: 'orderdetail',
      //   component: OrderdetailComponent,
      // },      
      // {
      //   path: 'shopthankyou',
      //   component: ShopThankyouComponent,
      // },
      // {
      //   path: 'addresses',
      //   component: AddressesComponent,
      // },
      // {
      //   path: 'addaddresses',
      //   component: AddaddressesComponent,
      // },      
      // {
      //   path: 'invoice',
      //   component: InvoiceComponent,
      // },
      // Todo App pages       
      // {
      //   path: 'todohome',
      //   component: TodohomeComponent,
      // },
      // {
      //   path: 'taskcalendar',
      //   component: TaskcalendarComponent,
      // },
      // {
      //   path: 'todaystask',
      //   component: TodaystaskComponent,
      // },
      // {
      //   path: 'events',
      //   component: EventsComponent,
      // },
      // {
      //   path: 'eventdetails',
      //   component: EventdetailsComponent,
      // },
      // Other pages      
      // {
      //   path: 'chat',
      //   component: ChatlistComponent,
      // },
      // {
      //   path: 'messages',
      //   component: MessagesComponent,
      // },
      // {
      //   path: 'notifications',
      //   component: NotificationsComponent,
      // },
      // {
      //   path: 'settings',
      //   component: SettingsComponent,
      // },
      // {
      //   path: 'pages',
      //   component: PagesComponent,
      // },
      // {
      //   path: 'pagenotfound',
      //   component: PagenotfoundComponent,
      // },
      // {
      //   path: 'faqs',
      //   component: FaqsComponent,
      // },
      // {
      //   path: 'userlist',
      //   component: UserlistComponent,
      // },
      // {
      //   path: 'timeline',
      //   component: TimelineComponent,
      // },
      // {
      //   path: 'contactus',
      //   component: ContactusComponent,
      // },
      // {
      //   path: 'pricing',
      //   component: PricingComponent,
      // },
      // {
      //   path: 'termsandconditions',
      //   component: TermsandcoditionComponent,
      // }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),    
  ],
  exports: [RouterModule]
})
export class AppinnerlayoutRoutingModule { }
