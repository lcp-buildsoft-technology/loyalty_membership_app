import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gamificationhome',
  templateUrl: './gamificationhome.component.html',
  styleUrls: ['./gamificationhome.component.scss']
})
export class GamificationhomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
