import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Bookingeventpayment3Component } from './bookingeventpayment3.component';

describe('Bookingeventpayment3Component', () => {
  let component: Bookingeventpayment3Component;
  let fixture: ComponentFixture<Bookingeventpayment3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Bookingeventpayment3Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Bookingeventpayment3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
