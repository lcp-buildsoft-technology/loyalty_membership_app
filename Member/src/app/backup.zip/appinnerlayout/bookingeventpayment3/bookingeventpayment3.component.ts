import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingeventpayment3',
  templateUrl: './bookingeventpayment3.component.html',
  styleUrls: ['./bookingeventpayment3.component.scss']
})
export class Bookingeventpayment3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
