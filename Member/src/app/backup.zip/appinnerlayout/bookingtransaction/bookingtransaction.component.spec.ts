import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingtransactionComponent } from './bookingtransaction.component';

describe('BookingtransactionComponent', () => {
  let component: BookingtransactionComponent;
  let fixture: ComponentFixture<BookingtransactionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookingtransactionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingtransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
