import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingtransaction',
  templateUrl: './bookingtransaction.component.html',
  styleUrls: ['./bookingtransaction.component.scss']
})
export class BookingtransactionComponent implements OnInit {
  showDiv = {
    All: false,
    Today: false,
    Yesterday: false,
  }

  constructor() { }

  ngOnInit(): void {
  }

}
