import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-termsandcodition',
  templateUrl: './termsandcodition.component.html',
  styleUrls: ['./termsandcodition.component.scss']
})
export class TermsandcoditionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
