import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VoucherhomeComponent } from './voucherhome.component';

describe('VoucherhomeComponent', () => {
  let component: VoucherhomeComponent;
  let fixture: ComponentFixture<VoucherhomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VoucherhomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VoucherhomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
