import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voucherhome',
  templateUrl: './voucherhome.component.html',
  styleUrls: ['./voucherhome.component.scss']
})
export class VoucherhomeComponent implements OnInit {
  showDiv = {
    History: false,
    New: false
  }

  constructor() { }

  ngOnInit(): void {
  }

}
