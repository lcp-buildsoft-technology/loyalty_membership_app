import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tieredloyaltyprogram',
  templateUrl: './tieredloyaltyprogram.component.html',
  styleUrls: ['./tieredloyaltyprogram.component.scss']
})
export class TieredloyaltyprogramComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
