import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TieredloyaltyprogramComponent } from './tieredloyaltyprogram.component';

describe('TieredloyaltyprogramComponent', () => {
  let component: TieredloyaltyprogramComponent;
  let fixture: ComponentFixture<TieredloyaltyprogramComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TieredloyaltyprogramComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TieredloyaltyprogramComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
