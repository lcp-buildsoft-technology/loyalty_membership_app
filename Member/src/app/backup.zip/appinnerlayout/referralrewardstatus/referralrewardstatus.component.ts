import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-referralrewardstatus',
  templateUrl: './referralrewardstatus.component.html',
  styleUrls: ['./referralrewardstatus.component.scss']
})
export class ReferralrewardstatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
