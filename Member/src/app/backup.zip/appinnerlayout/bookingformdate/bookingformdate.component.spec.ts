import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingformdateComponent } from './bookingformdate.component';

describe('BookingformdateComponent', () => {
  let component: BookingformdateComponent;
  let fixture: ComponentFixture<BookingformdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BookingformdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingformdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
