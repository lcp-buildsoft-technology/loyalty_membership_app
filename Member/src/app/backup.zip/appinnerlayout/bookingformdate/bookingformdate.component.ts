import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingformdate',
  templateUrl: './bookingformdate.component.html',
  styleUrls: ['./bookingformdate.component.scss']
})
export class BookingformdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
