import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingeventform',
  templateUrl: './bookingeventform.component.html',
  styleUrls: ['./bookingeventform.component.scss']
})
export class BookingeventformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
