import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onlinestoredetails',
  templateUrl: './onlinestoredetails.component.html',
  styleUrls: ['./onlinestoredetails.component.scss']
})
export class OnlinestoredetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
